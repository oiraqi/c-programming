int convert(const char *message, int numbers[]);
void generate(int n, const int numbers[]);